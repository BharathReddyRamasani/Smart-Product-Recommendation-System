"""
FastAPI application entrypoint.
Startup: connect MongoDB → seed data → train ML models.
"""
import os
from contextlib import asynccontextmanager
from fastapi import FastAPI
from fastapi.middleware.cors import CORSMiddleware
from dotenv import load_dotenv

load_dotenv()

from app.utils.database import connect_to_mongo, close_mongo, get_db
from app.utils.seed_data import seed_database
from app.ml.engine import ml_engine
from app.routes import auth, products, interactions, recommendations, cart, orders, profile
from app.schemas.schemas import HealthResponse
from app.utils.logger import get_logger

logger = get_logger(__name__)
APP_VERSION = "2.0.0"


@asynccontextmanager
async def lifespan(app: FastAPI):
    logger.info("=== Smart Recommendation System v2.0 Starting ===")
    db = connect_to_mongo()

    seed_enabled = os.getenv("SEED_ON_STARTUP", "true").lower() == "true"
    if seed_enabled:
        seed_database(db)

    ml_engine.fit(db)
    logger.info("=== System Ready ===")
    yield
    close_mongo()
    logger.info("=== System Stopped ===")


app = FastAPI(
    title="Smart Product Recommendation System",
    description="Production recommendation engine with MongoDB, JWT auth, and hybrid ML strategy.",
    version=APP_VERSION,
    lifespan=lifespan,
    docs_url="/docs",
    redoc_url="/redoc",
)

cors_origins = [o.strip() for o in os.getenv(
    "CORS_ORIGINS", "http://localhost:3000,http://localhost:5173"
).split(",")]

app.add_middleware(
    CORSMiddleware,
    allow_origins=cors_origins,
    allow_credentials=True,
    allow_methods=["*"],
    allow_headers=["*"],
)

PREFIX = "/api/v1"
app.include_router(auth.router, prefix=PREFIX)
app.include_router(products.router, prefix=PREFIX)
app.include_router(interactions.router, prefix=PREFIX)
app.include_router(recommendations.router, prefix=PREFIX)
app.include_router(cart.router, prefix=PREFIX)
app.include_router(orders.router, prefix=PREFIX)
app.include_router(profile.router, prefix=PREFIX)


@app.get("/health", response_model=HealthResponse, tags=["System"])
def health_check():
    db = get_db()
    return HealthResponse(
        status="healthy",
        version=APP_VERSION,
        total_users=db.users.count_documents({}),
        total_products=db.products.count_documents({}),
        total_interactions=db.interactions.count_documents({}),
        ml_engine_ready=ml_engine.is_ready,
    )


@app.get("/", tags=["System"])
def root():
    return {
        "message": "Smart Product Recommendation System v2.0",
        "docs": "/docs",
        "health": "/health",
        "auth": {"signup": "POST /api/v1/auth/signup", "login": "POST /api/v1/auth/login"},
        "public": ["GET /api/v1/products", "GET /api/v1/products/{id}"],
        "protected": ["GET /api/v1/home", "GET /api/v1/recommend/user",
                      "GET /api/v1/cart", "POST /api/v1/orders/place"],
    }
