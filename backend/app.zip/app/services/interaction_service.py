"""
Interaction service: handles creation and retrieval of user-product interactions.
After recording interactions, optionally triggers a lightweight ML engine refresh.
"""
from datetime import datetime
from sqlalchemy.orm import Session
from app.models.db_models import Interaction, User, Product
from app.schemas.schemas import InteractionCreate, InteractionResponse
from app.utils.logger import get_logger

logger = get_logger(__name__)

# Retrain after this many new interactions
RETRAIN_THRESHOLD = 50
_new_interactions_since_retrain = 0


def create_interaction(db: Session, data: InteractionCreate) -> InteractionResponse:
    """
    Record a new user-product interaction.
    
    Args:
        db: Database session
        data: Validated interaction data
    Returns:
        Created interaction
    Raises:
        ValueError: If user or product not found
    """
    global _new_interactions_since_retrain

    # Validate user exists
    user = db.query(User).filter(User.id == data.user_id).first()
    if not user:
        raise ValueError(f"User with id={data.user_id} not found")

    # Validate product exists
    product = db.query(Product).filter(Product.id == data.product_id).first()
    if not product:
        raise ValueError(f"Product with id={data.product_id} not found")

    interaction = Interaction(
        user_id=data.user_id,
        product_id=data.product_id,
        interaction_type=data.interaction_type,
        rating=data.rating,
        timestamp=datetime.utcnow(),
    )
    db.add(interaction)
    db.commit()
    db.refresh(interaction)

    _new_interactions_since_retrain += 1
    logger.info(
        f"Interaction recorded: user={data.user_id} product={data.product_id} "
        f"type={data.interaction_type}"
    )

    # Background retrain hint (actual retrain handled by periodic task or admin endpoint)
    if _new_interactions_since_retrain >= RETRAIN_THRESHOLD:
        _new_interactions_since_retrain = 0
        logger.info("Retrain threshold reached — consider refreshing ML models.")

    return InteractionResponse(
        id=interaction.id,
        user_id=interaction.user_id,
        product_id=interaction.product_id,
        interaction_type=interaction.interaction_type,
        rating=interaction.rating,
        timestamp=interaction.timestamp,
    )


def get_user_interactions(
    db: Session,
    user_id: int,
    limit: int = 50,
) -> list[InteractionResponse]:
    """
    Retrieve recent interactions for a given user.
    
    Args:
        db: Database session
        user_id: Target user
        limit: Maximum number of interactions to return
    Returns:
        List of interactions sorted by timestamp descending
    """
    interactions = (
        db.query(Interaction)
        .filter(Interaction.user_id == user_id)
        .order_by(Interaction.timestamp.desc())
        .limit(limit)
        .all()
    )
    return [
        InteractionResponse(
            id=i.id,
            user_id=i.user_id,
            product_id=i.product_id,
            interaction_type=i.interaction_type,
            rating=i.rating,
            timestamp=i.timestamp,
        )
        for i in interactions
    ]
