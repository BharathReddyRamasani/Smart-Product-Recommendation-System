"""
Recommendation service: bridges API routes ↔ ML engine ↔ database.
Enriches raw ML output (product_id, score) with full product details from DB.
"""
from typing import List, Optional
from sqlalchemy.orm import Session
from app.ml.engine import ml_engine
from app.models.db_models import Product, User
from app.schemas.schemas import RecommendedProduct, RecommendationResponse, SimilarProductResponse
from app.utils.logger import get_logger

logger = get_logger(__name__)


def _product_to_recommended(product: Product, score: float) -> RecommendedProduct:
    """Convert a DB Product ORM object + score into a RecommendedProduct schema."""
    return RecommendedProduct(
        product_id=product.id,
        name=product.name,
        category=product.category,
        price=product.price,
        description=product.description,
        features=product.features,
        image_url=product.image_url,
        brand=product.brand,
        rating=product.rating,
        score=score,
    )


def get_user_recommendations(
    db: Session,
    user_id: int,
    k: int = 10,
    strategy: str = "auto",
) -> RecommendationResponse:
    """
    Generate personalized recommendations for a user.
    
    Raises:
        ValueError: If user not found in database
    """
    # Validate user exists
    user = db.query(User).filter(User.id == user_id).first()
    if not user:
        raise ValueError(f"User with id={user_id} not found")

    results, strategy_used = ml_engine.recommend_for_user(
        user_id=user_id,
        k=k,
        strategy=strategy,
    )

    if not results:
        logger.warning(f"No recommendations generated for user {user_id}")
        return RecommendationResponse(
            user_id=user_id,
            strategy=strategy_used,
            recommendations=[],
            total=0,
        )

    # Enrich with product details from DB
    product_id_map = {pid: score for pid, score in results}
    products = db.query(Product).filter(Product.id.in_(product_id_map.keys())).all()
    product_lookup = {p.id: p for p in products}

    recommendations: list[RecommendedProduct] = []
    # Maintain ML ranking order
    for pid, score in results:
        if pid in product_lookup:
            recommendations.append(_product_to_recommended(product_lookup[pid], score))

    logger.info(
        f"User {user_id}: {len(recommendations)} recommendations via '{strategy_used}'"
    )

    return RecommendationResponse(
        user_id=user_id,
        strategy=strategy_used,
        recommendations=recommendations,
        total=len(recommendations),
    )


def get_similar_products(
    db: Session,
    product_id: int,
    k: int = 10,
) -> SimilarProductResponse:
    """
    Get products similar to the specified product using content-based filtering.
    
    Raises:
        ValueError: If product not found in database
    """
    # Validate product exists
    source_product = db.query(Product).filter(Product.id == product_id).first()
    if not source_product:
        raise ValueError(f"Product with id={product_id} not found")

    results, strategy_used = ml_engine.recommend_similar_products(
        product_id=product_id,
        k=k,
    )

    if not results:
        return SimilarProductResponse(
            source_product_id=product_id,
            source_product_name=source_product.name,
            strategy=strategy_used,
            recommendations=[],
            total=0,
        )

    product_id_map = {pid: score for pid, score in results}
    products = db.query(Product).filter(Product.id.in_(product_id_map.keys())).all()
    product_lookup = {p.id: p for p in products}

    recommendations: list[RecommendedProduct] = []
    for pid, score in results:
        if pid in product_lookup:
            recommendations.append(_product_to_recommended(product_lookup[pid], score))

    return SimilarProductResponse(
        source_product_id=product_id,
        source_product_name=source_product.name,
        strategy=strategy_used,
        recommendations=recommendations,
        total=len(recommendations),
    )


def get_all_products(db: Session, skip: int = 0, limit: int = 100) -> list[Product]:
    """Return paginated list of all products."""
    return db.query(Product).offset(skip).limit(limit).all()


def get_all_users(db: Session, skip: int = 0, limit: int = 100) -> list[User]:
    """Return paginated list of all users."""
    return db.query(User).offset(skip).limit(limit).all()


def get_metrics(k: int = 10) -> dict:
    """Delegate metric computation to the ML engine."""
    return ml_engine.get_metrics(k=k)
